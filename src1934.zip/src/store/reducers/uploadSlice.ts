import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { JsonDetailsObject } from "../../utils/constant/types";

type JsonDetails = Record<string,any>;

const initialState = {}

const uploadSlice = createSlice({
  name: "upload",
  initialState,
  reducers: {
    uploadFile: (state, action: PayloadAction<JsonDetails>) => {
      return {
        ...state,
        ...action.payload,
      };
    },
    updateData: (state, action: PayloadAction<JsonDetailsObject>) => {
      const { key, data: payloadData } = action.payload;
      return {
          ...state,
          [key]: payloadData,
      };
    },
  },
});
export const { uploadFile, updateData } = uploadSlice.actions;
export const selectDetails = (state: { details: JsonDetails }) =>
  state.details.value;
export default uploadSlice.reducer;
