import React, { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { useNavigate } from "react-router-dom";
import styles from "./apiValidator.module.scss";
import { Button, FileUpload, Radio } from "intelli-ui-components-library";
import {
  CloseIcon,
  DeleteIcon,
  DownloadIcon,
  ExecuteIcon,
  GenerateIcon,
  PawIcon,
  SaveIcon,
  UploadIcon,
} from "../../assets/icons";
import { LoadingOutlined, SettingOutlined } from "@ant-design/icons";
import Modals from "../modals/Modals";
import { uploadFile } from "../../store/reducers/uploadSlice";
import { exportData } from "../../store/reducers/exportSlice";
import { updateApiValidatorState } from "../../store/reducers/apiValidatorSlice";
import SelectFile from "../../assets/svgs/select_file.svg";
import SampleFile from "../../utils/constant/sample.csv";

const BASE_URL = "http://localhost:8080";

const uploadStatusColors = { success: "#039855", failure: "#b07272" };
const statusMessageRegex = /^upload-(.*?)-message/;

const GeneratePostmanCollection = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const apiValidator = useAppSelector((state) => state.apiValidator);
  const exportData = useAppSelector(state => state.export);

  const {
    isCreatingCollection,
    createdCollectionData,
    hasDownloadedCollection,
    apiSpecFileSelected
  } = apiValidator;

  const [jsonFile, setJsonFile] = useState<File | null>(null);
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [uploadStatusMessage, setUploadStatusMessage] = useState<{
    className: string;
    message: string;
  } | null>(null);

  const [modalData, setModalData] = useState({
    title: "",
    description: "",
    onConfirm: () => {},
    showModal: false,
  });
  const closeModal = () => {
    setModalData({
      title: "",
      description: "",
      onConfirm: () => {},
      showModal: false,
    });
  };

  const generatePostmanCollection = async () => {
    if (jsonFile === null && !apiSpecFileSelected && csvFile === null) {
      setUploadStatusMessage({
        message:
          "Both API Spec (.json) file and API Data (.csv) file are required.",
        className: "upload-failure-message",
      });
      setTimeout(()=>{
        setUploadStatusMessage(null)
      },3000);
      return;
    }
    if ((apiSpecFileSelected || jsonFile !== null) && csvFile === null) {
      setUploadStatusMessage({
        message:
          " API Data (.csv) file are required.",
        className: "upload-failure-message",
      });
      setTimeout(()=>{
        setUploadStatusMessage(null)
      },3000);
      return;
    }
    const formData = new FormData();
    if (jsonFile !== null) {
      formData.append("apiSpec", jsonFile);
    }
    if (jsonFile === null && apiSpecFileSelected) {
      const blob = new Blob([JSON.stringify(exportData)], {
        type: "application/json",
      });
      const file = new File([blob], "api-spec-data.json", { type: "application/json" });
      formData.append("api-spec-file", file);
    }

    if (csvFile !== null) {
      formData.append("apiData", csvFile);
    }
    
    dispatch(updateApiValidatorState({ isCreatingCollection: true }));
    try {
      let response = await fetch(`${BASE_URL}/createPostmanCollection`, {
        method: "POST",
        body: formData,
      });
      const data = await response.json();

      // const dataStr =
      //   "data:text/json;charset=utf-8," +
      //   encodeURIComponent(JSON.stringify(data));
      const dataStr = JSON.stringify(data, null, 2);

      dispatch(updateApiValidatorState({ createdCollectionData: dataStr }));
      dispatch(updateApiValidatorState({ hasCreatedCollection: true }));
    } catch (error) {
      console.log(error);
    }
    dispatch(updateApiValidatorState({ isCreatingCollection: false }));
    dispatch(updateApiValidatorState({ hasDownloadedCollection: false }));
  };

  const downloadCollectionData = () => {
    if (!createdCollectionData) {
      return;
    }
    const downloadAnchorNode = document.createElement("a");

    downloadAnchorNode.setAttribute(
      "href",
      "data:text/json;charset=utf-8," +
        encodeURIComponent(createdCollectionData)
    );
    downloadAnchorNode.setAttribute("download", "collection.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
    dispatch(updateApiValidatorState({ hasDownloadedCollection: true }));
  };

  const handleUploadJsonFile = (file: File) => {
    if (file) {
      setJsonFile(file);
      setUploadStatusMessage({
        message: `${file.name} uploaded succesfully`,
        className: "upload-success-message",
      });
      setTimeout(()=>{
        setUploadStatusMessage(null)
      },3000);
      dispatch(
        updateApiValidatorState({
          apiSpecFileSelected: false,
        })
      );
    }
  };

  const handleUploadCsvFile = (file: File) => {
    if (file) {
      setCsvFile(file);
      setUploadStatusMessage({
        message: `${file.name} uploaded succesfully`,
        className: "upload-success-message",
      });
      setTimeout(()=>{
        setUploadStatusMessage(null)
      },3000);
    }
  };
  const handleChange = (e:any) =>{
    dispatch(
      updateApiValidatorState({
        apiSpecFileSelected: true,
      })
    );
    
  }

  return (
    <div className={styles.container}>
      <div>
        <div className={styles.uploadFiles}>
          <h4 style={{ marginTop: "20px" }}>Upload API Spec file</h4>
          <h4 style={{ marginTop: "20px" }}>Upload API Data file</h4>
        </div>
        <div className={styles.uploadFiles}>
          <div className={styles.selectFile}>
            <img src={SelectFile} alt="" />
            <h4>Select a file or drag and drop here</h4>
            <p>Accepted file type: .json or .yaml only</p>
            <FileUpload
              id={"jsonFileUpload"}
              fileInputClass={styles.fileUpload}
              onFileSelect={handleUploadJsonFile}
              fileType=".json,.yaml"
            />
          </div>
          <div className={styles.selectFile}>
            <img src={SelectFile} alt="" />
            <h4>Select a file or drag and drop here</h4>
            <p>Accepted file type: .csv only</p>

            <FileUpload
              id={"csvFileUpload"}
              fileInputClass={styles.fileUpload}
              onFileSelect={handleUploadCsvFile}
              fileType=".csv"
            />
          </div>
        </div>
      </div>
      { apiSpecFileSelected && (
          <div style={{marginTop:"-20px"}}>
            <div
              className={styles.itemDist}
              onClick={handleChange}
            >
              <Radio
                label="Api spec file"
                size="sm"
                checked={apiSpecFileSelected}  

              />
            </div>
            <div className={styles.itemCenter}>
              <p
                style={{
                  color: "#ff6600",
                }}
              >
                api-spec-data.json
              </p>
            </div>
          </div> )}
          <span style={apiSpecFileSelected? {marginLeft:"78%", marginTop:"-40px"} : {marginLeft:"78%"}}><a download="data-template.csv" target="_blank" href={SampleFile} style={{color:"#ff6600", textDecoration:"underline"}}>Downlaod CSV Data Template</a></span>
      {uploadStatusMessage !== null && (
        <div className={styles[uploadStatusMessage.className]}>
          <div> {uploadStatusMessage.message}</div>
          <div onClick={() => setUploadStatusMessage(null)}>
            <CloseIcon
              fill={
                uploadStatusColors[
                  `${uploadStatusMessage.className.replace(
                    statusMessageRegex,
                    "$1"
                  )}`
                ]
              }
              height={"16px"}
              width={"16px"}
            />
          </div>
        </div>
      )}

      <div className={`${styles["button-group"]}`}>
        <div>
          <Button
            round="round"
            className={styles["button1"]}
            onClick={generatePostmanCollection}
          >
            <span className={styles["button-icon"]}>
              {isCreatingCollection ? (
                <LoadingOutlined />
              ) : (
                <GenerateIcon width={"20px"} height={"20px"} />
              )}
            </span>
            {isCreatingCollection ? `Generating....` : "Generate"}
          </Button>
          {createdCollectionData.length > 0 && (
            <Button
              round="round"
              color="success"
              className={
                hasDownloadedCollection === false
                  ? `${styles["button2"]} ${styles["bg-green"]}`
                  : styles["button2"]
              }
              onClick={downloadCollectionData}
            >
              <span className={styles["button-icon"]}>
                <DownloadIcon fill="#ff6600" width={"20px"} height={"20px"} />
              </span>
              {hasDownloadedCollection === false ? `Download` : `Download`}
            </Button>
          )}

          {createdCollectionData.length > 0 && (
            <Button
              round="round"
              color="success"
              className={`${styles["button1"]} ${styles["bg-green"]}`}
              onClick={() => {
                dispatch(
                  updateApiValidatorState({
                    fileSelectForReport: "generated",
                  })
                );
                navigate("/test-wizard/test-executor");
              }}
            >
              <span className={styles["button-icon"]}>
                <ExecuteIcon fill="#ff6600" width={"18px"} height={"18px"} />
              </span>
              Execute
            </Button>
          )}
        </div>

        {modalData.showModal && (
          <Modals
            showModal={modalData.showModal}
            header={modalData.title}
            description={modalData.description}
            onConfirm={modalData.onConfirm}
            onCancel={closeModal}
            childClassName=""
          />
        )}
      </div>
    </div>
  );
};

export default GeneratePostmanCollection;
