import AddTag from "./AddTag";
import styles from "./tags.module.scss";
import { useAppSelector, useAppDispatch } from "../../store/hooks";
import { useEffect, useState } from "react";
import { tagsData } from "../../store/reducers/tagsSlice";
import { AddIcon, CloseIcon, LeftArrowIcon, RightArrowIcon, SaveIcon } from "../../assets/icons";
import { Button, Tooltip } from "intelli-ui-components-library";
import { exportData } from "../../store/reducers/exportSlice";
import { useNavigate } from "react-router-dom";

const Tags = () => {
  const navigate = useNavigate();
  const UploadData = useAppSelector((state) => state.export);
  const dispatch = useAppDispatch();
  const newData = { ...UploadData };
  const { tags } = newData;
  const newTags = useAppSelector((state) => state.tags.tags);
  const [alertMsg, setAlertMsg] = useState(false);
  useEffect(() => {
    tags
      ? dispatch(tagsData({ key: "tags", data: tags }))
      : dispatch(tagsData({ key: "tags", data: [] }));
  }, [UploadData]);

  const onSave = () => {
    newData["tags"] = [...newTags];
    dispatch(exportData({ ...newData }));
    setAlertMsg(true)
    setTimeout(()=>{
      setAlertMsg(false)
    },3000);
    navigate("/api-doc-gen/schemas")
  };
  const addNewTag = () => {
    const tagsObj = [...newTags];
    let dup = true;
    const newTag = {
      name: "newTag",
    };
    tagsObj.map((obj) => {
      if (obj.name === "newTag") {
        dup = false;
      }
    });
    if (dup) {
      tagsObj.push(newTag);
      dispatch(tagsData({ key: "tags", data: tagsObj }));
    }
  };
  return (
    <div className={styles.container}>
      <div
        style={{
          height: "24em",
          overflowY: "scroll",
        }}
      >
        <div className={styles["tag-addicon"]}>
          <Tooltip message="Add tag" position="top">
            <button className={styles["add-icon"]} onClick={addNewTag}>
              <AddIcon fill="#FFFFFF" width="16px" height="16px" />
            </button>
          </Tooltip>
        </div>

        {newTags.length > 0 && (
          <div className={styles["tags-container"]}>
            {newTags.map((obj: any, index: number) => (
              <AddTag tag={obj} index={index} />
            ))}
          </div>
        )}
      </div>
      {alertMsg && (
        <div className={styles["success-message"]}>
          <div>Saved Successfully</div>
          <div onClick={() => setAlertMsg(false)}>
            <CloseIcon
              height={"16px"}
              width={"16px"}
            />
          </div>
        </div>
      )}
        <div className={styles["tag-button"]}>
          <Button className={styles["button"]} onClick={onSave}>
            {" "}
            Next
            <span>
              <RightArrowIcon fill="#FFFFFF" width={"18px"} height={"16px"} />
            </span>
          </Button>
          <Button className={styles["button"]} onClick={()=>navigate("/api-doc-gen/api-servers")}>
            {" "}
            <span style={{marginRight:"3px"}}>
              <LeftArrowIcon fill="#FFFFFF" width={"18px"} height={"16px"} />
            </span>
            Back
          </Button>
        </div>
    </div>
  );
};
export default Tags;
